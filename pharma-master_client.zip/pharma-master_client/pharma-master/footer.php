
<?php
	$con=mysqli_connect("localhost","root","","janvi")
?>
<html>

<head>
  <title>Pharma &mdash; Colorlib Template</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link href="https://fonts.googleapis.com/css?family=Rubik:400,700|Crimson+Text:400,400i" rel="stylesheet">
  <link rel="stylesheet" href="fonts/icomoon/style.css">

  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/magnific-popup.css">
  <link rel="stylesheet" href="css/jquery-ui.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">


  <link rel="stylesheet" href="css/aos.css">

  <link rel="stylesheet" href="css/style.css">

</head>
<body>
    <footer class="site-footer">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-lg-3 mb-4 mb-lg-0">

            <div class="block-7">
              <h3 class="footer-heading mb-4">About Us</h3>
              <p>The purpose of this Pharmacy Management System project is to improve the maintenance and manipulation of the drugs in the medicals.</p>
            </div>

          </div>
          <div class="col-lg-3 mx-auto mb-5 mb-lg-0">
            <h3 class="footer-heading mb-4">Quick Links</h3>
            <ul class="list-unstyled">
              <li><a href="footer.php">Supplements</a></li>
              <li><a href="footer.php">Vitamins</a></li>
              <li><a href="footer.php">Diet &amp; Nutrition</a></li>
              <li><a href="footer.php">Tea &amp; Coffee</a></li>
            </ul>
          </div>

          <div class="col-md-6 col-lg-3">
            <div class="block-5 mb-5">
              <h3 class="footer-heading mb-4">Contact Info</h3>
              <ul class="list-unstyled">
                <li class="address">Ul72, Shreemad Bhavan, Dhebar Road, Rajkot Railway Station, Rajkot - 360001</li>
                <li class="phone"><a href="tel://9909725368">+91 990 9725 368</a></li>
                <li class="email">pharma01@gamil.com</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </footer>
  </div>
</body>
